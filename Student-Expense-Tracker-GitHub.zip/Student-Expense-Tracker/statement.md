# Project Statement

## Project Title
Student Expense Tracker

## Problem Statement
Students often need to manage daily expenses such as food, travel, stationery, and other personal spending. Keeping these records manually can make it difficult to understand total spending and remaining budget.

This project provides a simple Python-based system to record expenses, search expenses, calculate spending summaries, and monitor a monthly budget.

## Scope
The project focuses on personal expense tracking for students. It stores expense information and budget information locally using JSON and text files.

## Target Users
- College students
- Hostel students
- Students who want to track daily spending

## High-Level Features
- Add expense
- View expenses
- Search by category
- Calculate total spending
- Calculate category-wise spending
- Set monthly budget
- Check remaining budget
- Delete expense
- Save and load data

## Main Functional Modules
1. Expense Management
2. Expense Search and Reporting
3. Budget Management
4. Data Storage

## Non-Functional Requirements
1. Usability - The menu should be simple for a beginner to use.
2. Reliability - Data should be saved locally.
3. Error Handling - Invalid numeric input should be handled.
4. Maintainability - The program is divided into separate Python files.

## Technologies
Python 3, JSON, text-file storage, standard Python libraries.
