from storage import save_data, load_data

def test_save_and_load():
    sample = [{
        "amount": 100,
        "category": "Food",
        "description": "Lunch",
        "date": "29-09-2026"
    }]
    save_data(sample)
    assert load_data() == sample

if __name__ == "__main__":
    test_save_and_load()
    print("Storage test passed.")
