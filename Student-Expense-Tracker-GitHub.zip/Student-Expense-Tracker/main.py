from expense_manager import add_expense, show_expenses, search_expense, show_summary, delete_expense
from budget_manager import set_budget, check_budget
from storage import load_data

def main():
    expenses = load_data()

    while True:
        print("\n==============================")
        print("     STUDENT EXPENSE TRACKER")
        print("==============================")
        print("1. Add Expense")
        print("2. View Expenses")
        print("3. Search Expense")
        print("4. Expense Summary")
        print("5. Set Monthly Budget")
        print("6. Check Budget")
        print("7. Delete Expense")
        print("8. Exit")
        print("==============================")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            show_expenses(expenses)
        elif choice == "3":
            search_expense(expenses)
        elif choice == "4":
            show_summary(expenses)
        elif choice == "5":
            set_budget()
        elif choice == "6":
            check_budget(expenses)
        elif choice == "7":
            delete_expense(expenses)
        elif choice == "8":
            print("Thank you for using the Expense Tracker!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
