import json
from pathlib import Path

EXPENSE_FILE = Path("data/expenses.json")
BUDGET_FILE = Path("data/budget.txt")

def load_data():
    try:
        with open(EXPENSE_FILE, "r") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_data(expenses):
    EXPENSE_FILE.parent.mkdir(exist_ok=True)
    with open(EXPENSE_FILE, "w") as file:
        json.dump(expenses, file, indent=4)

def save_budget(budget):
    BUDGET_FILE.parent.mkdir(exist_ok=True)
    with open(BUDGET_FILE, "w") as file:
        file.write(str(budget))

def get_budget():
    try:
        with open(BUDGET_FILE, "r") as file:
            return float(file.read())
    except (FileNotFoundError, ValueError):
        return 0
