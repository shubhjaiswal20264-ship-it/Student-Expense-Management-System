from datetime import datetime
from storage import save_data

def add_expense(expenses):
    print("\n--- Add Expense ---")
    try:
        amount = float(input("Enter amount: "))
        if amount <= 0:
            print("Amount must be greater than 0.")
            return
    except ValueError:
        print("Please enter a valid amount.")
        return

    category = input("Enter category: ").strip()
    description = input("Enter description: ").strip()

    if not category:
        print("Category cannot be empty.")
        return

    new_expense = {
        "amount": amount,
        "category": category,
        "description": description,
        "date": datetime.now().strftime("%d-%m-%Y")
    }

    expenses.append(new_expense)
    save_data(expenses)
    print("Expense added successfully!")

def show_expenses(expenses):
    print("\n--- Your Expenses ---")
    if not expenses:
        print("No expenses added yet.")
        return

    for i, expense in enumerate(expenses, start=1):
        print(f"\nExpense {i}")
        print("Amount      :", expense["amount"])
        print("Category    :", expense["category"])
        print("Description :", expense["description"])
        print("Date        :", expense["date"])

def search_expense(expenses):
    print("\n--- Search Expense ---")
    category = input("Enter category: ").strip().lower()
    found = False

    for expense in expenses:
        if expense["category"].lower() == category:
            print("₹", expense["amount"], "|", expense["description"], "|", expense["date"])
            found = True

    if not found:
        print("No expense found in this category.")

def show_summary(expenses):
    print("\n--- Expense Summary ---")
    if not expenses:
        print("No expenses available.")
        return

    total = sum(expense["amount"] for expense in expenses)
    category_total = {}

    for expense in expenses:
        category = expense["category"]
        category_total[category] = category_total.get(category, 0) + expense["amount"]

    print("Total spending: ₹", total)
    print("\nCategory-wise spending:")
    for category, amount in category_total.items():
        print(category, ": ₹", amount)

def delete_expense(expenses):
    print("\n--- Delete Expense ---")
    if not expenses:
        print("No expenses available.")
        return

    show_expenses(expenses)

    try:
        number = int(input("\nEnter expense number to delete: "))
        if 1 <= number <= len(expenses):
            deleted = expenses.pop(number - 1)
            save_data(expenses)
            print("Expense for ₹", deleted["amount"], "deleted successfully.")
        else:
            print("Invalid expense number.")
    except ValueError:
        print("Please enter a number.")
