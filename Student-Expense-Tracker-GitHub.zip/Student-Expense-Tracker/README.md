# Student Expense Tracker

A beginner-friendly Python project for tracking student expenses and monthly budgets.

## Project Overview

The Student Expense Tracker allows a user to:
- Add expenses
- View all expenses
- Search expenses by category
- See total and category-wise spending
- Set a monthly budget
- Check remaining budget
- Delete an expense
- Save data so it remains available after restarting the program

## Features

1. Expense Management
2. Expense Search and Viewing
3. Expense Summary and Analysis
4. Monthly Budget Management
5. Persistent File Storage

## Technologies Used

- Python 3
- JSON
- Text file storage
- Python standard library

## Project Structure

```text
Student-Expense-Tracker/
│
├── main.py
├── expense_manager.py
├── budget_manager.py
├── storage.py
├── requirements.txt
├── README.md
├── statement.md
│
├── data/
│   ├── expenses.json
│   └── budget.txt
│
└── tests/
    └── test_storage.py
```

## How to Run

1. Install Python 3.
2. Download or clone this repository.
3. Open the project folder in VS Code, IDLE, or another Python IDE.
4. Run:

```bash
python main.py
```

## Testing

Run:

```bash
python tests/test_storage.py
```

Expected output:

```text
Storage test passed.
```

## Input / Output

### Input
- Expense amount
- Category
- Description
- Monthly budget
- Menu choice

### Output
- Expense records
- Total spending
- Category-wise spending
- Budget status
- Confirmation/error messages

## Future Enhancements

- Login system
- Monthly expense reports
- Graphs and charts
- Export to CSV
- Expense editing
- GUI using Tkinter
- SQLite database

## Academic Project

This project is prepared as a student project and demonstrates Python functions, conditions, loops, lists, dictionaries, file handling, JSON, exception handling, and modular programming.
