from storage import save_budget, get_budget

def set_budget():
    print("\n--- Set Budget ---")
    try:
        budget = float(input("Enter your monthly budget: "))
        if budget <= 0:
            print("Budget must be greater than 0.")
            return
        save_budget(budget)
        print("Budget saved successfully!")
    except ValueError:
        print("Please enter a valid amount.")

def check_budget(expenses):
    print("\n--- Budget Status ---")
    budget = get_budget()

    if budget == 0:
        print("Please set your budget first.")
        return

    total = sum(expense["amount"] for expense in expenses)
    remaining = budget - total

    print("Monthly budget :", budget)
    print("Total spent    :", total)
    print("Remaining      :", remaining)

    if remaining > 0:
        print("You are within your budget.")
    elif remaining == 0:
        print("You have used your complete budget.")
    else:
        print("You have exceeded your budget.")
